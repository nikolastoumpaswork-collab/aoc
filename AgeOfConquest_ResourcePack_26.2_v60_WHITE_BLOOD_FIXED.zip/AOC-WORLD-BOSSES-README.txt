Age of Conquest v44 exact per-cube world-boss renderer.
Each original Blockbench cube is rendered independently and driven by its original bone pivot,
parent hierarchy, UV rectangle, inflation, animation position and animation rotation.

4.4.1: corrected boss facing, forced live animation ticks, and repaired Dude wing UV planes.

AOC Ancient Crate resource integration

Item model keys:
- aoc_ancient:ancient_crate -> full Inferno 3D chest model
- aoc_ancient:ancient_crate_key -> full Inferno 3D key model

These models are used by CrazyCrates/crates/Ancient.yml.
All previous AOC resource-pack assets remain included.

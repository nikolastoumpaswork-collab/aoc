Ancient Inferno integration notes (v31)
- Fixed Ancient chestplate item render: it now uses the supplied Inferno chestplate icon.
- The previous v30 build incorrectly pointed the chestplate item at infernoset:item/chest, which is the purchased pack's placeable furniture chest model.
- The equipped chestplate still uses the Inferno wearable armour layer through assets/aoc_ancient/equipment/inferno.json.
- Ancient helmet keeps its full 3D Inferno helmet item model.
- Ancient Relics have no release-window lock; admin generation remains available at any time.

AOC TOWN GUARD MODEL ENGINE v51

Guard movement and combat-animation rebuild:
- Walking cycles are driven by actual distance travelled, preventing floating/sliding.
- Smooth idle-to-walk and walk-to-idle blending.
- Sword guards visibly wind up, strike at the damage moment, and recover.
- Ranged guards visibly aim, draw, release a real arrow, recoil, and recover.
- Archers stop moving while firing and use normal pathfinding speed when repositioning.
- Town containment, hostile-mob defence, war targeting, and friendly safety remain active.
- World-boss code, models, animations, and assets are unchanged.

Requires AOC Towny 4.7.0 and this v51 resource pack together.

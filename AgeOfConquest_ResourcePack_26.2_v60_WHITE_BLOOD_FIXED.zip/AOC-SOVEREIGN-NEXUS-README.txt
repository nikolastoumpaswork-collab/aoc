AOC Sovereign Nexus v27 render fix
The previous pack loaded geometry but left Nexus textures outside the item atlas, producing magenta/black models.
This build places all model textures under assets/nexusset/textures/item and uses matching nexusset:item paths.


V28 FULL 3D WINGS
The Greaves of Belisarius now spawn the purchased Nexus wing geometry as a non-persistent Paper ItemDisplay behind the player. The visual uses aoc_relics:nexus_wings_display and does not create or duplicate a relic item.

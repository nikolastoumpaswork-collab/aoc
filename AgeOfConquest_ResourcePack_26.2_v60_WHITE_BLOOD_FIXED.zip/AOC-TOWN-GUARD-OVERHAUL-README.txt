AGE OF CONQUEST — TOWN GUARD RUNTIME v47

Required plugin: AgeOfConquestTowny 4.5.1

This pack keeps the v46 world-boss assets unchanged. The town-guard correction is
implemented by the 4.5.1 plugin renderer: it uses only the supplied idle pose as
the base animation, adds restrained walk movement, and no longer uses the supplied
"hello" greeting animation as a combat animation. That greeting clip was causing
the models to fold, lean and separate in combat.

Archer hosts are now Skeletons firing real arrows. Existing Snow Golem guards are
automatically removed and respawned by the plugin, eliminating snow trails.

All five Arcane Vanguard model assets remain included under namespace aocguards45.

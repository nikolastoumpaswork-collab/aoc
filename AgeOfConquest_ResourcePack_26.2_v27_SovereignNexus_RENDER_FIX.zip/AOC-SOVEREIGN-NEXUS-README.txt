AOC Sovereign Nexus v27 render fix
The previous pack loaded geometry but left Nexus textures outside the item atlas, producing magenta/black models.
This build places all model textures under assets/nexusset/textures/item and uses matching nexusset:item paths.

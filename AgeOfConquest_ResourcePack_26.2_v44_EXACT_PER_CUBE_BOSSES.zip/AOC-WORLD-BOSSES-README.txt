Age of Conquest v44 exact per-cube world-boss renderer.
Each original Blockbench cube is rendered independently and driven by its original bone pivot,
parent hierarchy, UV rectangle, inflation, animation position and animation rotation.

AOC WHITE BLOOD RELICS — RESOURCE PACK MERGE
=============================================

Merged into the existing Age of Conquest v58 resource pack without removing existing assets.

Integrated armour visuals:
- White Blood helmet item model
- White Blood chestplate/leggings/boots inventory icons
- White Blood worn armour fallback textures
- Supplied EMF/ETF files retained for optional enhanced 3D rendering on compatible Java clients

The matching server plugin is:
AOCWhiteBloodRelics-1.1.0-RESOURCE-PACK-ARMOR.jar

The plugin assigns these item model keys:
- white_blood:helmet
- white_blood:chestplate
- white_blood:leggings
- white_blood:boots

And these equipment model keys:
- mythicarmor:white_blood_armor_helmet_piece
- mythicarmor:white_blood_armor_chest_piece
- mythicarmor:white_blood_armor_legs_piece
- mythicarmor:white_blood_armor_feet_piece

Existing White Blood relics in player inventories are refreshed on join by the plugin.

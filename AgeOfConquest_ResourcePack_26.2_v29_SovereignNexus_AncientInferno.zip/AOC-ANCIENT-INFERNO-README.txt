Ancient AOC Relics Inferno model integration
Plugin: AOCAncientRelics 1.2.0+
Item model namespace: aoc_ancient
Equipment model: aoc_ancient:inferno
No Oraxen, ItemsAdder or Nexo plugin is required.

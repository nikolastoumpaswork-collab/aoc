Age of Conquest Resource Pack v24 — Refined AOCChat Animation

Changes from v23:
- Only the rank prefix is affected by the shader.
- The moving per-letter rainbow has been removed.
- Rank colours now change in discrete frames based on the existing TAB palettes.
- Player names, town text, badge/tag text and messages retain their normal styling.
- The scoreboard logo and all existing v22/v23 assets remain included.

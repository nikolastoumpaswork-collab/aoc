AOC White Blood v63
===================
Built from AOC v58.

Fixes:
- White Blood item textures moved into the native item atlas.
- White Blood weapon/item models use AOC-native item_model definitions.
- Armor inventory icons use native item-atlas textures.
- Worn armor uses the product-supplied vanilla fallback layers.

Important:
The purchased pack explicitly states that exact 3D chestplate/leggings/boots require MythicArmor's 1.21.6+ shader system. Those generated shaders/equipment assets are not included in white_blood.zip, so a normal server pack cannot reproduce that exact 3D worn geometry.

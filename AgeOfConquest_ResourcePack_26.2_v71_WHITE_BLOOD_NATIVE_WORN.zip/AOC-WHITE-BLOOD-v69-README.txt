AOC White Blood v69
- Custom worn display models use standard assets/aoc_whiteblood/models/item paths for all four armor slots.
- Pack-side fixed transforms normalized; renderer plugin controls player scale.
- Native equipment textures restored as a dedicated White Blood fallback for inventory/F5 paper-doll rendering.
- Ancient armor assets are untouched.

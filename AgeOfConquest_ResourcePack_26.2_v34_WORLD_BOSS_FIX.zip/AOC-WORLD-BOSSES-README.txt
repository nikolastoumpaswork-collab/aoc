Age of Conquest custom world-boss models — v34 render and animation fix.
Rendered directly by AgeOfConquestTowny; ModelEngine and MythicMobs are not required.
Includes normalised UVs, safe Java-model bounds and merged emissive layers.

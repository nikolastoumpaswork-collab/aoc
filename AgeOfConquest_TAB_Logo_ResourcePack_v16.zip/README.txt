Age of Conquest TAB Logo Pack v11

Extreme size reduction:
- actual logo artwork: max 28x28 pixels
- bitmap height: 1
- bitmap ascent: 0
- logo positioned low inside the 128x128 texture

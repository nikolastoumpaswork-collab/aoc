Ancient Inferno integration notes (v30)
- Ancient helmet now renders using the full Inferno 3D helmet model.
- Ancient chestplate now renders using the full Inferno 3D chest model.
- Leggings and boots continue to use the wearable layered armour textures because the purchased Inferno pack does not include separate 3D meshes for those slots.
- Ancient Relics no longer enforce a release-window lock. Admin generation is always allowed.

AOC TOWN GUARD MODEL ENGINE v49

This build fixes guard geometry by moving every source cube rotation out of Minecraft item-model JSON and into AOC runtime quaternion bones.
World-boss code and world-boss assets are unchanged.
Requires AOC Towny 4.6.1 and this v49 resource pack together.

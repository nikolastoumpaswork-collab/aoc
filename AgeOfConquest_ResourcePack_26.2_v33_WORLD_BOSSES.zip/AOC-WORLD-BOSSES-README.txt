Age of Conquest custom world-boss models.
These assets are rendered directly by the AgeOfConquestTowny plugin.
No ModelEngine or MythicMobs installation is required.

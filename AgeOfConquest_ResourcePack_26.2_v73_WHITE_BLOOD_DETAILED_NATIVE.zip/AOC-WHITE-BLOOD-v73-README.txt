AOC Resource Pack v73 - White Blood Detailed Native Worn Armour

- Rebuilt White Blood worn armour texture directly from the original White Blood 3D armour skin/artwork.
- No Ancient armour assets used or recoloured.
- Native Minecraft equipment rendering only: no display entities, MythicArmor, Nexo, EMF or client mods required.
- Stronger silver plate bevels, navy undersuit, crimson piping, magenta blood-line highlights, chest V motif and detailed leggings.
- Existing White Blood held/inventory weapon and armour item models remain unchanged.

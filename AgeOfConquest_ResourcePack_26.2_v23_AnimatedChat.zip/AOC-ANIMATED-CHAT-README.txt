AGE OF CONQUEST RESOURCE PACK v23

This pack preserves the existing AOC scoreboard logo and adds a Minecraft 26.2
core text shader used by AOCChat-1.0.0.jar.

Java Edition:
- OWNER, ADMIN, MOD, HELPER, WARLORD and PILGRIM chat prefixes animate
  continuously, including messages already visible in chat.

Bedrock Edition:
- Geyser/Floodgate players receive static rank colours because Bedrock cannot
  execute Java Edition core shaders.

Important:
- Client shader packs or mods that replace Minecraft's core text shader can
  override this effect.
- The server must send this exact pack to Java players.

#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

bool close_rgb(vec3 actual, vec3 expected255) {
    return distance(actual * 255.0, expected255) < 2.0;
}

// Returns +rank for the normal glyph and -rank for Minecraft's dark text shadow.
int aoc_rank_marker(vec3 rgb) {
    if (close_rgb(rgb, vec3(252.0,   4.0,   4.0))) return  1; // OWNER
    if (close_rgb(rgb, vec3( 63.0,   1.0,   1.0))) return -1;

    if (close_rgb(rgb, vec3(252.0,  68.0,   4.0))) return  2; // ADMIN
    if (close_rgb(rgb, vec3( 63.0,  17.0,   1.0))) return -2;

    if (close_rgb(rgb, vec3(  4.0, 132.0, 252.0))) return  3; // MOD
    if (close_rgb(rgb, vec3(  1.0,  33.0,  63.0))) return -3;

    if (close_rgb(rgb, vec3(  4.0, 252.0,  68.0))) return  4; // HELPER
    if (close_rgb(rgb, vec3(  1.0,  63.0,  17.0))) return -4;

    if (close_rgb(rgb, vec3(252.0, 132.0,   4.0))) return  5; // WARLORD
    if (close_rgb(rgb, vec3( 63.0,  33.0,   1.0))) return -5;

    if (close_rgb(rgb, vec3(164.0,   4.0, 252.0))) return  6; // PILGRIM
    if (close_rgb(rgb, vec3( 41.0,   1.0,  63.0))) return -6;

    return 0;
}

vec3 loop6(vec3 c0, vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, float t) {
    float p = fract(t) * 6.0;
    if (p < 1.0) return mix(c0, c1, p);
    if (p < 2.0) return mix(c1, c2, p - 1.0);
    if (p < 3.0) return mix(c2, c3, p - 2.0);
    if (p < 4.0) return mix(c3, c4, p - 3.0);
    if (p < 5.0) return mix(c4, c5, p - 4.0);
    return mix(c5, c0, p - 5.0);
}

vec3 aoc_palette(int rank, float t) {
    if (rank == 1) { // Owner: dark red -> red -> orange -> gold -> white
        return loop6(
            vec3(0.545, 0.000, 0.000),
            vec3(1.000, 0.000, 0.000),
            vec3(1.000, 0.274, 0.000),
            vec3(1.000, 0.843, 0.000),
            vec3(1.000, 1.000, 1.000),
            vec3(1.000, 0.843, 0.000), t);
    }
    if (rank == 2) { // Admin
        return loop6(
            vec3(0.545, 0.000, 0.000),
            vec3(1.000, 0.000, 0.000),
            vec3(1.000, 0.549, 0.000),
            vec3(1.000, 0.843, 0.000),
            vec3(1.000, 1.000, 1.000),
            vec3(1.000, 0.274, 0.000), t);
    }
    if (rank == 3) { // Moderator
        return loop6(
            vec3(0.000, 0.000, 0.545),
            vec3(0.000, 0.549, 1.000),
            vec3(0.000, 1.000, 1.000),
            vec3(1.000, 1.000, 1.000),
            vec3(0.000, 0.749, 1.000),
            vec3(0.000, 0.300, 0.850), t);
    }
    if (rank == 4) { // Helper
        return loop6(
            vec3(0.000, 0.392, 0.000),
            vec3(0.000, 1.000, 0.000),
            vec3(0.678, 1.000, 0.184),
            vec3(1.000, 1.000, 1.000),
            vec3(0.200, 1.000, 0.300),
            vec3(0.000, 0.550, 0.100), t);
    }
    if (rank == 5) { // Warlord
        return loop6(
            vec3(0.392, 0.000, 0.000),
            vec3(1.000, 0.000, 0.000),
            vec3(1.000, 0.271, 0.000),
            vec3(1.000, 0.843, 0.000),
            vec3(1.000, 0.271, 0.000),
            vec3(0.650, 0.000, 0.000), t);
    }
    // Pilgrim
    return loop6(
        vec3(0.416, 0.353, 0.804),
        vec3(0.576, 0.439, 0.859),
        vec3(0.855, 0.439, 0.839),
        vec3(1.000, 1.000, 1.000),
        vec3(0.855, 0.439, 0.839),
        vec3(0.576, 0.439, 0.859), t);
}

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    int marker = aoc_rank_marker(vertexColor.rgb);
    vec4 effectiveVertexColor = vertexColor;

    if (marker != 0) {
        int rank = marker < 0 ? -marker : marker;
        // GameTime completes one full unit every Minecraft day. Multiplying by
        // 1200 creates roughly a one-second colour cycle, while screen X adds
        // a moving gradient across the letters.
        float phase = fract(GameTime * 1200.0 + gl_FragCoord.x * 0.014);
        vec3 animated = aoc_palette(rank, phase);
        if (marker < 0) {
            animated *= 0.25;
        }
        effectiveVertexColor = vec4(animated, vertexColor.a);
    }

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * effectiveVertexColor;
#else
    vec4 color = texColor * effectiveVertexColor * ColorModulator;
#endif

    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}

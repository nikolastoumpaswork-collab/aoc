AOC Resource Pack v74 - White Blood High Detail Native Armour

- Completely rebuilt worn White Blood textures at 512x256.
- Uses a separate base + transparent detail equipment layer to preserve plate lines at player scale.
- Dark recessed seams, silver bevels, crimson piping, magenta blood lines, knee chevrons and high-contrast panel segmentation.
- Visual reference is the original White Blood 3D armour skin; no Ancient armour texture assets are used.
- Native Minecraft equipment rendering only. No display entities or custom renderer plugin.

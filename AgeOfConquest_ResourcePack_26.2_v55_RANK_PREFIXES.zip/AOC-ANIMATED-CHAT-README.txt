AGE OF CONQUEST CUSTOM RANK PREFIXES v55

The former animated text prefixes have been replaced by the seven pixel-art
rank badges supplied in ranks.aseprite:

Owner, Admin, Mod, Helper, Warlord, Pilgrim and Civilian.

The glyphs are registered in both minecraft:default and aoc:ranks. This keeps
normal Minecraft text intact while allowing the same rank art to render in
TAB, chat and the AOC self-nametag display.

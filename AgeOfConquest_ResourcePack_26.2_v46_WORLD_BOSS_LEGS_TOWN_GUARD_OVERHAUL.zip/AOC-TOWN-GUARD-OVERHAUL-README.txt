AGE OF CONQUEST — TOWN GUARD OVERHAUL (v46)

Use this resource pack together with AOC-Towny 4.5.0.

Included:
- Native AOC conversions of all five supplied Ginko Arcane Vanguard NPCs.
- Deterministic ranged-guard variants: Wildwood Alchemist, Crystal Sage, Rune Archmage.
- Deterministic royal-guard variants: Crimson Knight, Silvermane Blademaster.
- Supplied idle, secondary-idle and greeting/combat animation tracks.
- Procedural walking leg/arm movement and body motion while guards navigate.
- Consolidated per-bone display rendering to avoid one display entity per source cube.
- Updated world-boss leg locomotion for The Void Collector, Voidfall Behemoth and Infernal Devourer.

The plugin retains the existing guard recruitment, town ownership, rally, retreat, persistence, war targeting and death behaviour.

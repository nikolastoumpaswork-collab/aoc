AGE OF CONQUEST TAB LOGO PACK

Glyph: U+E001
Visible character to copy: 

TAB header example:
header:
  - "<font:aoc:logo></font>"
  - "&4&lAGE OF CONQUEST"
  - "&7Forge Your Legacy"

The glyph is also added to Minecraft's default font, so this works too:
  - ""

Install the ZIP as your server resource pack. Do not extract it for hosting.

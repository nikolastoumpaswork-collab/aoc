Age of Conquest Resource Pack v26
Merged primary server pack for Minecraft/Paper 26.2.

Includes:
- Existing AOC scoreboard logo, rank-emblem font and animated chat shader
- Nexus Animated Weapons & Tools Set assets used by AOC Sovereign Relics
- 18 aoc_relics item-model definitions
- Nexus wearable equipment textures

Plugin: AOCSovereignRelics 2.8.1 or later
Source model credit: PolygonMC / Nexus Animated Weapons & Tools Set

AOC Guard Model Engine v48
Exact parent-pivot renderer for the supplied Ginko Fantasy Arcane Vanguard guards.
World-boss assets are unchanged.

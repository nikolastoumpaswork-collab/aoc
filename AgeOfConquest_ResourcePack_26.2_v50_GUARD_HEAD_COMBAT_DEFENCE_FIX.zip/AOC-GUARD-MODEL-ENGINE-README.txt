AOC TOWN GUARD MODEL ENGINE v50

Guard-only update:
- Corrects backwards guard heads at the source head-bone level.
- Adds active hostile-mob and wartime town-defence AI.
- Keeps guards contained inside their owning town claims.
- World-boss code, models, animations and resource assets are unchanged.
Requires AOC Towny 4.6.2 and this v50 pack together.

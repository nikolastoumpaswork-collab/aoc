Age of Conquest v36 world-boss model rebuild.
Every visible part is anchored to its original Blockbench bone pivot, UV coordinates are preserved exactly,
and a new namespace prevents stale client model cache entries. No external model plugin is required.

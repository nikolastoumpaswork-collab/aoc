Updated AOC animated rank chat resource pack. Includes refined rank-only animations for Owner, Admin, Mod, Helper, Warlord and Pilgrim. Compatible with AOCChat-1.0.2.

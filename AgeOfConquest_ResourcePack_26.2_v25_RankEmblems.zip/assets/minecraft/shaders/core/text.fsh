#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

vec3 rgb255(float r, float g, float b) {
    return vec3(r, g, b) / 255.0;
}

bool close_rgb(vec3 actual, vec3 expected255) {
    return distance(actual * 255.0, expected255) < 2.0;
}

// Returns +rank for the normal glyph and -rank for Minecraft's dark text shadow.
// These marker colours are emitted only by AOCChat's rank-prefix component.
int aoc_rank_marker(vec3 rgb) {
    if (close_rgb(rgb, vec3(252.0,   4.0,   4.0))) return  1; // OWNER
    if (close_rgb(rgb, vec3( 63.0,   1.0,   1.0))) return -1;

    if (close_rgb(rgb, vec3(252.0,  68.0,   4.0))) return  2; // ADMIN
    if (close_rgb(rgb, vec3( 63.0,  17.0,   1.0))) return -2;

    if (close_rgb(rgb, vec3(  4.0, 132.0, 252.0))) return  3; // MOD
    if (close_rgb(rgb, vec3(  1.0,  33.0,  63.0))) return -3;

    if (close_rgb(rgb, vec3(  4.0, 252.0,  68.0))) return  4; // HELPER
    if (close_rgb(rgb, vec3(  1.0,  63.0,  17.0))) return -4;

    if (close_rgb(rgb, vec3(252.0, 132.0,   4.0))) return  5; // WARLORD
    if (close_rgb(rgb, vec3( 63.0,  33.0,   1.0))) return -5;

    if (close_rgb(rgb, vec3(164.0,   4.0, 252.0))) return  6; // PILGRIM
    if (close_rgb(rgb, vec3( 41.0,   1.0,  63.0))) return -6;

    return 0;
}

vec3 frame_mid(vec3 startColor, vec3 endColor) {
    // TAB's prefix frames are gradients. A single midpoint colour keeps the
    // same frame palette and timing without the distracting moving rainbow.
    return mix(startColor, endColor, 0.5);
}


vec3 aoc_frame_color(int rank, int frame) {
    if (rank == 1) { // owner-prefix: regal red -> gold -> white pulse
        if (frame == 0) return frame_mid(rgb255(139.0,   0.0,   0.0), rgb255(255.0,   0.0,   0.0));
        if (frame == 1) return frame_mid(rgb255(255.0,   0.0,   0.0), rgb255(255.0, 140.0,   0.0));
        if (frame == 2) return frame_mid(rgb255(255.0, 140.0,   0.0), rgb255(255.0, 215.0,   0.0));
        if (frame == 3) return frame_mid(rgb255(255.0, 215.0,   0.0), rgb255(255.0, 255.0, 255.0));
        if (frame == 4) return frame_mid(rgb255(255.0, 255.0, 255.0), rgb255(255.0, 215.0,   0.0));
        return frame_mid(rgb255(255.0, 215.0,   0.0), rgb255(255.0,   0.0,   0.0));
    }

    if (rank == 2) { // admin-prefix: warm command glow
        if (frame == 0) return frame_mid(rgb255(160.0,   0.0,   0.0), rgb255(255.0,  35.0,   0.0));
        if (frame == 1) return frame_mid(rgb255(255.0,  35.0,   0.0), rgb255(255.0, 120.0,   0.0));
        if (frame == 2) return frame_mid(rgb255(255.0, 120.0,   0.0), rgb255(255.0, 200.0,  60.0));
        return frame_mid(rgb255(255.0, 200.0,  60.0), rgb255(255.0,  35.0,   0.0));
    }

    if (rank == 3) { // mod-prefix: blue guard shimmer
        if (frame == 0) return frame_mid(rgb255(  0.0,  40.0, 150.0), rgb255(  0.0, 110.0, 255.0));
        if (frame == 1) return frame_mid(rgb255(  0.0, 110.0, 255.0), rgb255( 90.0, 210.0, 255.0));
        if (frame == 2) return frame_mid(rgb255( 90.0, 210.0, 255.0), rgb255(255.0, 255.0, 255.0));
        return frame_mid(rgb255(255.0, 255.0, 255.0), rgb255(  0.0, 110.0, 255.0));
    }

    if (rank == 4) { // helper-prefix: soft healing pulse
        if (frame == 0) return frame_mid(rgb255(  0.0, 120.0,  20.0), rgb255(  0.0, 220.0,  40.0));
        if (frame == 1) return frame_mid(rgb255(  0.0, 220.0,  40.0), rgb255(120.0, 255.0, 120.0));
        if (frame == 2) return frame_mid(rgb255(120.0, 255.0, 120.0), rgb255(255.0, 255.0, 255.0));
        return frame_mid(rgb255(255.0, 255.0, 255.0), rgb255(  0.0, 220.0,  40.0));
    }

    if (rank == 5) { // warlord-prefix: aggressive ember sweep
        if (frame == 0) return frame_mid(rgb255(120.0,   0.0,   0.0), rgb255(210.0,  20.0,   0.0));
        if (frame == 1) return frame_mid(rgb255(210.0,  20.0,   0.0), rgb255(255.0,  90.0,   0.0));
        if (frame == 2) return frame_mid(rgb255(255.0,  90.0,   0.0), rgb255(255.0, 185.0,  25.0));
        return frame_mid(rgb255(255.0, 185.0,  25.0), rgb255(210.0,  20.0,   0.0));
    }

    // pilgrim-prefix: calm violet holy glow
    if (frame == 0) return frame_mid(rgb255(100.0,  70.0, 190.0), rgb255(135.0, 100.0, 220.0));
    if (frame == 1) return frame_mid(rgb255(135.0, 100.0, 220.0), rgb255(190.0, 120.0, 235.0));
    if (frame == 2) return frame_mid(rgb255(190.0, 120.0, 235.0), rgb255(255.0, 255.0, 255.0));
    return frame_mid(rgb255(255.0, 255.0, 255.0), rgb255(135.0, 100.0, 220.0));
}

int aoc_frame(int rank) {
    if (rank == 1) {
        return int(floor(fract(GameTime * 1333.333333) * 6.0));
    }
    if (rank == 2) {
        return int(floor(fract(GameTime * 1363.636364) * 4.0));
    }
    if (rank == 3) {
        return int(floor(fract(GameTime * 1666.666667) * 4.0));
    }
    if (rank == 4) {
        return int(floor(fract(GameTime * 1250.0) * 4.0));
    }
    if (rank == 5) {
        return int(floor(fract(GameTime * 1764.705882) * 4.0));
    }
    return int(floor(fract(GameTime * 1111.111111) * 4.0));
}


void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    int marker = aoc_rank_marker(vertexColor.rgb);
    vec4 effectiveVertexColor = vertexColor;

    if (marker != 0) {
        int rank = marker < 0 ? -marker : marker;
        vec3 animated = aoc_frame_color(rank, aoc_frame(rank));
        if (marker < 0) {
            animated *= 0.25;
        }
        effectiveVertexColor = vec4(animated, vertexColor.a);
    }

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * effectiveVertexColor;
#else
    vec4 color = texColor * effectiveVertexColor * ColorModulator;
#endif

    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}

Age of Conquest v37 exact cube renderer.
Each original Blockbench cube is now a separately transformed display part. Group pivots, hierarchy,
cube centres, dimensions, UVs and animation channels are retained without Java item-model pivot approximation.
